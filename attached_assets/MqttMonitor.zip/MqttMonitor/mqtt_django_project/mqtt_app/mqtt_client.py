"""
MQTT client implementation for Django integration
"""
import paho.mqtt.client as mqtt
import threading
import logging
import json
import time
from django.conf import settings
from django.utils import timezone
from django.db import transaction
from jsonpath_ng import jsonpath, parse

# Configure logging
logger = logging.getLogger(__name__)

# Global variable to hold the MQTT client instance
_mqtt_client = None
_client_lock = threading.Lock()

def on_connect(client, userdata, flags, rc):
    """
    Callback for when the client connects to the broker
    """
    if rc == 0:
        logger.info("Connected to MQTT broker")
        # Subscribe to default topics
        from .models import MQTTTopic
        topics = MQTTTopic.objects.filter(is_subscribed=True)
        for topic in topics:
            client.subscribe(topic.topic, topic.qos)
            logger.info(f"Subscribed to topic: {topic.topic} with QoS: {topic.qos}")
    else:
        connection_result = {
            1: "Connection refused - incorrect protocol version",
            2: "Connection refused - invalid client identifier",
            3: "Connection refused - server unavailable",
            4: "Connection refused - bad username or password",
            5: "Connection refused - not authorized"
        }
        error_msg = connection_result.get(rc, f"Unknown error code: {rc}")
        logger.error(f"Failed to connect to MQTT broker: {error_msg}")


def on_disconnect(client, userdata, rc):
    """
    Callback for when the client disconnects from the broker
    """
    if rc != 0:
        logger.warning(f"Unexpected disconnection from MQTT broker with code {rc}")
    else:
        logger.info("Disconnected from MQTT broker")


def on_message(client, userdata, msg):
    """
    Callback for when a message is received from the broker
    """
    try:
        from .models import MQTTMessage, MQTTTopic
        
        # Decode payload if it's bytes
        if isinstance(msg.payload, bytes):
            try:
                payload = msg.payload.decode('utf-8')
            except UnicodeDecodeError:
                # If it's not UTF-8 encoded text, store as hex string
                payload = msg.payload.hex()
        else:
            payload = str(msg.payload)
        
        # Check if this topic is configured to handle JSON payloads
        topic_config = MQTTTopic.objects.filter(topic=msg.topic, is_subscribed=True).first()
        if topic_config and topic_config.is_json_payload:
            # Try to format JSON for better readability
            try:
                # Parse JSON
                json_obj = json.loads(payload)
                
                # Check if we need to extract a specific field using JSONPath
                if topic_config.json_path_selector:
                    try:
                        # Parse the JSONPath expression
                        jsonpath_expr = parse(topic_config.json_path_selector)
                        
                        # Find all matches
                        matches = [match.value for match in jsonpath_expr.find(json_obj)]
                        
                        if matches:
                            # If only one match, use it directly
                            if len(matches) == 1:
                                extracted_value = matches[0]
                                logger.info(f"Extracted value using JSONPath '{topic_config.json_path_selector}': {extracted_value}")
                                
                                # If extracted value is a complex type, format it as JSON
                                if isinstance(extracted_value, (dict, list)):
                                    payload = json.dumps(extracted_value, indent=2)
                                else:
                                    payload = str(extracted_value)
                            else:
                                # Multiple matches, return as JSON array
                                logger.info(f"Found multiple matches ({len(matches)}) using JSONPath '{topic_config.json_path_selector}'")
                                payload = json.dumps(matches, indent=2)
                        else:
                            logger.warning(f"No matches found for JSONPath '{topic_config.json_path_selector}'")
                            # Keep the original JSON but formatted
                            payload = json.dumps(json_obj, indent=2)
                    except Exception as e:
                        logger.error(f"Error processing JSONPath '{topic_config.json_path_selector}': {e}")
                        # Fallback to the full JSON
                        payload = json.dumps(json_obj, indent=2)
                else:
                    # No JSONPath specified, just format the whole JSON
                    payload = json.dumps(json_obj, indent=2)
                
                logger.info(f"Processed JSON payload for topic '{msg.topic}'")
            except json.JSONDecodeError:
                logger.warning(f"Topic '{msg.topic}' is marked as JSON but payload is not valid JSON")
        
        # Log the message
        logger.info(f"Received message on topic '{msg.topic}': {payload}")
        
        # Save message to database with transaction to handle concurrent access
        with transaction.atomic():
            MQTTMessage.objects.create(
                topic=msg.topic,
                payload=payload,
                qos=msg.qos
            )
    except Exception as e:
        logger.error(f"Error processing MQTT message: {e}")


def get_mqtt_client():
    """
    Get the MQTT client instance (singleton pattern)
    """
    global _mqtt_client
    return _mqtt_client


def initialize_mqtt_client():
    """
    Initialize the MQTT client with settings from Django settings or database
    """
    global _mqtt_client
    
    with _client_lock:
        if _mqtt_client is not None:
            return _mqtt_client
        
        try:
            # Try to get configuration from database first
            from .models import MQTTConfiguration
            config = MQTTConfiguration.objects.filter(is_active=True).first()
            
            if config:
                broker_host = config.broker_host
                broker_port = config.broker_port
                username = config.username
                password = config.password
                client_id = config.client_id
                keepalive = config.keepalive
                # SSL/TLS parameters
                use_tls = config.use_tls
                ca_cert = config.ca_cert
                client_cert = config.client_cert
                client_key = config.client_key
                tls_version = config.tls_version
                cert_reqs = config.cert_reqs
            else:
                # Fall back to settings if no config in database
                broker_host = settings.MQTT_BROKER_HOST
                broker_port = settings.MQTT_BROKER_PORT
                username = settings.MQTT_USERNAME
                password = settings.MQTT_PASSWORD
                client_id = settings.MQTT_CLIENT_ID
                keepalive = settings.MQTT_KEEPALIVE
                use_tls = getattr(settings, 'MQTT_USE_TLS', False)
                ca_cert = getattr(settings, 'MQTT_CA_CERT', None)
                client_cert = getattr(settings, 'MQTT_CLIENT_CERT', None)
                client_key = getattr(settings, 'MQTT_CLIENT_KEY', None)
                tls_version = getattr(settings, 'MQTT_TLS_VERSION', 'tlsv1.2')
                cert_reqs = getattr(settings, 'MQTT_CERT_REQS', 'required')
            
            # Create new MQTT client
            client = mqtt.Client(client_id=client_id)
            
            # Set callbacks
            client.on_connect = on_connect
            client.on_disconnect = on_disconnect
            client.on_message = on_message
            
            # Set username and password if provided
            if username and password:
                client.username_pw_set(username, password)
            
            # Configure TLS/SSL if enabled
            if use_tls:
                try:
                    import ssl
                    import tempfile
                    import os
                    
                    # Map string values to SSL constants
                    tls_version_map = {
                        'tlsv1.2': ssl.PROTOCOL_TLSv1_2,
                        'tlsv1.1': ssl.PROTOCOL_TLSv1_1,
                        'tlsv1': ssl.PROTOCOL_TLSv1,
                    }
                    
                    cert_reqs_map = {
                        'none': ssl.CERT_NONE,
                        'required': ssl.CERT_REQUIRED
                    }
                    
                    tls_protocol = tls_version_map.get(tls_version, ssl.PROTOCOL_TLSv1_2)
                    cert_validation = cert_reqs_map.get(cert_reqs, ssl.CERT_REQUIRED)
                    
                    # Create temporary files for certificates
                    ca_cert_path = None
                    client_cert_path = None
                    client_key_path = None
                    
                    try:
                        if ca_cert:
                            with tempfile.NamedTemporaryFile(delete=False, suffix='.pem') as temp_ca_file:
                                temp_ca_file.write(ca_cert.encode())
                                ca_cert_path = temp_ca_file.name
                        
                        if client_cert:
                            with tempfile.NamedTemporaryFile(delete=False, suffix='.pem') as temp_cert_file:
                                temp_cert_file.write(client_cert.encode())
                                client_cert_path = temp_cert_file.name
                        
                        if client_key:
                            with tempfile.NamedTemporaryFile(delete=False, suffix='.key') as temp_key_file:
                                temp_key_file.write(client_key.encode())
                                client_key_path = temp_key_file.name
                        
                        # Configure TLS
                        logger.info(f"Configuring TLS for MQTT connection with TLS version {tls_version}")
                        client.tls_set(
                            ca_certs=ca_cert_path,
                            certfile=client_cert_path,
                            keyfile=client_key_path,
                            cert_reqs=cert_validation,
                            tls_version=tls_protocol
                        )
                        
                        # Disable hostname verification if not required
                        if cert_reqs == 'none':
                            client.tls_insecure_set(True)
                            
                    finally:
                        # Clean up temporary files in case of exception
                        # Note: In production, files will be deleted after connection
                        if ca_cert_path and os.path.exists(ca_cert_path):
                            try:
                                os.unlink(ca_cert_path)
                            except:
                                pass
                        if client_cert_path and os.path.exists(client_cert_path):
                            try:
                                os.unlink(client_cert_path)
                            except:
                                pass
                        if client_key_path and os.path.exists(client_key_path):
                            try:
                                os.unlink(client_key_path)
                            except:
                                pass
                
                except Exception as e:
                    logger.error(f"Error configuring TLS for MQTT client: {e}")
            
            # Set the global client
            _mqtt_client = client
            
            # Start the connection
            try:
                logger.info(f"Connecting to MQTT broker at {broker_host}:{broker_port}")
                client.connect_async(broker_host, broker_port, keepalive)
                client.loop_start()
                
                # Wait briefly to check connection
                time.sleep(0.5)
                if not client.is_connected():
                    logger.warning("Initial connection not established yet, but client is starting in background")
            except Exception as e:
                logger.error(f"Error connecting to MQTT broker: {e}")
            
            return client
        
        except Exception as e:
            logger.error(f"Error initializing MQTT client: {e}")
            return None


def connect_mqtt_client():
    """
    Manually connect to MQTT broker
    """
    # When manually connecting, it's better to reinitialize the client
    # to ensure it has the latest configuration including TLS settings
    global _mqtt_client
    
    # If there's an existing client, disconnect it first
    if _mqtt_client is not None and _mqtt_client.is_connected():
        try:
            _mqtt_client.disconnect()
            _mqtt_client.loop_stop()
        except Exception as e:
            logger.warning(f"Error disconnecting existing client: {e}")
    
    # Set _mqtt_client to None to force reinitialization
    with _client_lock:
        _mqtt_client = None
    
    # Reinitialize client with latest settings
    client = initialize_mqtt_client()
    
    if client:
        try:
            if not client.is_connected():
                # Wait a bit for connection to establish
                time.sleep(1)
                
                # If still not connected, check status
                if not client.is_connected():
                    logger.info("Client not immediately connected, but is attempting connection in background")
                
                return True
            else:
                logger.info("MQTT client connected successfully")
                return True
        except Exception as e:
            logger.error(f"Error connecting to MQTT broker: {e}")
            return False
    return False


def disconnect_mqtt_client():
    """
    Manually disconnect from MQTT broker
    """
    client = get_mqtt_client()
    if client and client.is_connected():
        try:
            client.disconnect()
            client.loop_stop()
            return True
        except Exception as e:
            logger.error(f"Error disconnecting from MQTT broker: {e}")
            return False
    return False


def publish_message(topic, payload, qos=0, retain=False):
    """
    Publish a message to the MQTT broker
    """
    client = get_mqtt_client()
    if client is None:
        client = initialize_mqtt_client()
    
    if client and client.is_connected():
        try:
            # Convert payload to JSON if it's a dict
            if isinstance(payload, dict):
                payload = json.dumps(payload)
            
            # Publish the message
            result = client.publish(topic, payload, qos, retain)
            
            # Check if the message was published successfully
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                logger.info(f"Published message to topic '{topic}': {payload}")
                # Also save the published message to our database
                from .models import MQTTMessage
                MQTTMessage.objects.create(
                    topic=topic,
                    payload=payload,
                    qos=qos
                )
                return True
            else:
                logger.error(f"Failed to publish message to topic '{topic}': {mqtt.error_string(result.rc)}")
                return False
        except Exception as e:
            logger.error(f"Error publishing MQTT message: {e}")
            return False
    else:
        logger.error("Cannot publish message: MQTT client is not connected")
        return False


def subscribe_to_topic(topic, qos=0):
    """
    Subscribe to an MQTT topic
    """
    client = get_mqtt_client()
    if client is None:
        client = initialize_mqtt_client()
    
    if client and client.is_connected():
        try:
            result = client.subscribe(topic, qos)
            if result[0] == mqtt.MQTT_ERR_SUCCESS:
                logger.info(f"Subscribed to topic '{topic}' with QoS {qos}")
                return True
            else:
                logger.error(f"Failed to subscribe to topic '{topic}': {mqtt.error_string(result[0])}")
                return False
        except Exception as e:
            logger.error(f"Error subscribing to topic: {e}")
            return False
    else:
        logger.error("Cannot subscribe to topic: MQTT client is not connected")
        return False


def unsubscribe_from_topic(topic):
    """
    Unsubscribe from an MQTT topic
    """
    client = get_mqtt_client()
    if client is None:
        return False
    
    if client and client.is_connected():
        try:
            result = client.unsubscribe(topic)
            if result[0] == mqtt.MQTT_ERR_SUCCESS:
                logger.info(f"Unsubscribed from topic '{topic}'")
                return True
            else:
                logger.error(f"Failed to unsubscribe from topic '{topic}': {mqtt.error_string(result[0])}")
                return False
        except Exception as e:
            logger.error(f"Error unsubscribing from topic: {e}")
            return False
    else:
        logger.error("Cannot unsubscribe from topic: MQTT client is not connected")
        return False
