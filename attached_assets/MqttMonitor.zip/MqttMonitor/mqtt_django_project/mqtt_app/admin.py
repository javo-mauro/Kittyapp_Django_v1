"""
Admin configuration for the MQTT app
"""
from django.contrib import admin
from .models import MQTTMessage, MQTTConfiguration

@admin.register(MQTTMessage)
class MQTTMessageAdmin(admin.ModelAdmin):
    list_display = ('topic', 'payload', 'qos', 'received_at')
    list_filter = ('topic', 'qos', 'received_at')
    search_fields = ('topic', 'payload')
    readonly_fields = ('received_at',)

@admin.register(MQTTConfiguration)
class MQTTConfigurationAdmin(admin.ModelAdmin):
    list_display = ('name', 'broker_host', 'broker_port', 'is_active')
    list_filter = ('is_active',)
