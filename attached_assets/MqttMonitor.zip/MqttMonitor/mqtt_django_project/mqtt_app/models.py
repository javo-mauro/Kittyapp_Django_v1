"""
Models for the MQTT application
"""
from django.db import models


class MQTTConfiguration(models.Model):
    """
    Model to store MQTT broker configuration details
    """
    name = models.CharField(max_length=100)
    broker_host = models.CharField(max_length=255)
    broker_port = models.IntegerField(default=1883)
    username = models.CharField(max_length=100, blank=True, null=True)
    password = models.CharField(max_length=100, blank=True, null=True)
    client_id = models.CharField(max_length=100)
    keepalive = models.IntegerField(default=60)
    is_active = models.BooleanField(default=True)
    
    # SSL/TLS Certificate fields
    use_tls = models.BooleanField(default=False, verbose_name="Use TLS/SSL")
    ca_cert = models.TextField(blank=True, null=True, verbose_name="CA Certificate")
    client_cert = models.TextField(blank=True, null=True, verbose_name="Client Certificate")
    client_key = models.TextField(blank=True, null=True, verbose_name="Client Key")
    tls_version = models.CharField(
        max_length=20, 
        choices=[
            ('tlsv1.2', 'TLS v1.2'),
            ('tlsv1.1', 'TLS v1.1'),
            ('tlsv1', 'TLS v1')
        ],
        default='tlsv1.2',
        blank=True,
        null=True
    )
    cert_reqs = models.CharField(
        max_length=20,
        choices=[
            ('none', 'None (Don\'t validate server)'),
            ('required', 'Required (Validate server)')
        ],
        default='required',
        blank=True,
        null=True
    )
    
    def __str__(self):
        return f"{self.name} ({self.broker_host}:{self.broker_port})"
    
    class Meta:
        verbose_name = "MQTT Configuration"
        verbose_name_plural = "MQTT Configurations"


class MQTTTopic(models.Model):
    """
    Model to store MQTT topics for subscription
    """
    topic = models.CharField(max_length=255)
    qos = models.IntegerField(default=0, choices=[(0, '0 - At most once'), (1, '1 - At least once'), (2, '2 - Exactly once')])
    is_subscribed = models.BooleanField(default=True)
    is_json_payload = models.BooleanField(default=False, verbose_name="Payload is JSON data")
    json_path_selector = models.CharField(max_length=255, blank=True, null=True, verbose_name="JSON Path (ej: $.temperatura)", 
                                         help_text="Selector para extraer variables específicas del JSON (ej: $.temperatura, $.datos.sensor)")
    
    def __str__(self):
        return f"{self.topic} (QoS: {self.qos})"
    
    class Meta:
        verbose_name = "MQTT Topic"
        verbose_name_plural = "MQTT Topics"


class MQTTMessage(models.Model):
    """
    Model to store received MQTT messages
    """
    topic = models.CharField(max_length=255)
    payload = models.TextField()
    qos = models.IntegerField(default=0)
    received_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.topic}: {self.payload[:50]}..."
    
    class Meta:
        verbose_name = "MQTT Message"
        verbose_name_plural = "MQTT Messages"
        ordering = ['-received_at']
