"""
Views for the MQTT app
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib import messages
from django.conf import settings
from django.views.decorators.http import require_POST
import json

from .models import MQTTMessage, MQTTConfiguration, MQTTTopic
from .forms import MQTTPublishForm, MQTTConfigurationForm, MQTTTopicForm
from .mqtt_client import get_mqtt_client, publish_message, subscribe_to_topic, unsubscribe_from_topic

def dashboard(request):
    """
    Dashboard view that shows MQTT status and recent messages
    """
    # Get active MQTT configuration
    mqtt_config = MQTTConfiguration.objects.filter(is_active=True).first()
    
    # Get recent messages
    recent_messages = MQTTMessage.objects.all().order_by('-received_at')[:10]
    
    # Get subscribed topics
    topics = MQTTTopic.objects.filter(is_subscribed=True)
    
    # Get MQTT client status
    client = get_mqtt_client()
    is_connected = client.is_connected() if client else False
    
    context = {
        'is_connected': is_connected,
        'mqtt_config': mqtt_config,
        'recent_messages': recent_messages,
        'topics': topics,
    }
    
    return render(request, 'mqtt_app/dashboard.html', context)

def message_list(request):
    """
    View that shows a list of all MQTT messages
    """
    # Get topic filter from query parameters
    topic_filter = request.GET.get('topic', '')
    
    # Filter messages by topic if provided
    if topic_filter:
        messages = MQTTMessage.objects.filter(topic__icontains=topic_filter).order_by('-received_at')
    else:
        messages = MQTTMessage.objects.all().order_by('-received_at')
    
    # Get unique topics for filter dropdown
    topics = MQTTMessage.objects.values_list('topic', flat=True).distinct()
    
    context = {
        'messages': messages,
        'topics': topics,
        'topic_filter': topic_filter,
    }
    
    return render(request, 'mqtt_app/messages.html', context)

def publish_view(request):
    """
    View that allows publishing MQTT messages
    """
    if request.method == 'POST':
        form = MQTTPublishForm(request.POST)
        if form.is_valid():
            topic = form.cleaned_data['topic']
            payload = form.cleaned_data['payload']
            qos = int(form.cleaned_data['qos'])
            retain = form.cleaned_data['retain']
            
            # Check if payload is JSON
            try:
                # Try to parse the payload as JSON
                json_payload = json.loads(payload)
                # If it's valid JSON, use the parsed object for publishing
                result = publish_message(topic, json_payload, qos, retain)
            except json.JSONDecodeError:
                # Not JSON, use as is
                result = publish_message(topic, payload, qos, retain)
            
            if result:
                messages.success(request, f"Message published to {topic}")
            else:
                messages.error(request, "Failed to publish message. Check if MQTT client is connected.")
            
            return redirect('mqtt_app:publish')
    else:
        form = MQTTPublishForm()
    
    # Check MQTT client status
    mqtt_client = get_mqtt_client()
    is_connected = mqtt_client is not None and mqtt_client.is_connected()
    
    context = {
        'form': form,
        'is_connected': is_connected,
    }
    
    return render(request, 'mqtt_app/publish.html', context)

def settings_view(request):
    """
    View to manage MQTT configuration and topic subscriptions
    """
    # Handle MQTT configuration form
    if request.method == 'POST' and 'config_form' in request.POST:
        config_form = MQTTConfigurationForm(request.POST)
        if config_form.is_valid():
            # If setting this as active, deactivate others
            if config_form.cleaned_data['is_active']:
                MQTTConfiguration.objects.update(is_active=False)
            
            config_form.save()
            messages.success(request, "MQTT configuration saved successfully.")
            return redirect('mqtt_app:settings')
    else:
        config_form = MQTTConfigurationForm()
    
    # Handle MQTT topic form
    if request.method == 'POST' and 'topic_form' in request.POST:
        topic_form = MQTTTopicForm(request.POST)
        if topic_form.is_valid():
            topic = topic_form.save()
            
            # Subscribe to the topic if it's marked as subscribed
            if topic.is_subscribed:
                success = subscribe_to_topic(topic.topic, topic.qos)
                if success:
                    messages.success(request, f"Subscribed to topic: {topic.topic}")
                else:
                    messages.error(request, f"Failed to subscribe to topic: {topic.topic}")
            
            return redirect('mqtt_app:settings')
    else:
        topic_form = MQTTTopicForm()
    
    # Get existing configurations and topics
    configs = MQTTConfiguration.objects.all()
    topics = MQTTTopic.objects.all()
    
    context = {
        'config_form': config_form,
        'topic_form': topic_form,
        'configs': configs,
        'topics': topics,
    }
    
    return render(request, 'mqtt_app/settings.html', context)

@require_POST
def toggle_topic_subscription(request, topic_id):
    """
    View to toggle a topic's subscription status
    """
    topic = get_object_or_404(MQTTTopic, id=topic_id)
    
    # Toggle subscription status
    topic.is_subscribed = not topic.is_subscribed
    topic.save()
    
    # Subscribe or unsubscribe based on new status
    if topic.is_subscribed:
        success = subscribe_to_topic(topic.topic, topic.qos)
        message = f"Subscribed to topic: {topic.topic}"
    else:
        success = unsubscribe_from_topic(topic.topic)
        message = f"Unsubscribed from topic: {topic.topic}"
    
    if success:
        messages.success(request, message)
    else:
        messages.error(request, f"Failed to update subscription for topic: {topic.topic}")
    
    return redirect('mqtt_app:settings')

@require_POST
def delete_topic(request, topic_id):
    """
    View to delete a topic
    """
    topic = get_object_or_404(MQTTTopic, id=topic_id)
    
    # Unsubscribe from topic before deleting
    if topic.is_subscribed:
        unsubscribe_from_topic(topic.topic)
    
    topic_name = topic.topic
    topic.delete()
    
    messages.success(request, f"Topic deleted: {topic_name}")
    return redirect('mqtt_app:settings')

@require_POST
def connect_mqtt(request):
    """
    View to manually connect to MQTT broker
    """
    from .mqtt_client import connect_mqtt_client
    
    success = connect_mqtt_client()
    
    if success:
        messages.success(request, "Connected to MQTT broker successfully.")
    else:
        messages.error(request, "Failed to connect to MQTT broker. Check configuration and try again.")
    
    return redirect('mqtt_app:dashboard')

@require_POST
def disconnect_mqtt(request):
    """
    View to manually disconnect from MQTT broker
    """
    from .mqtt_client import disconnect_mqtt_client
    
    success = disconnect_mqtt_client()
    
    if success:
        messages.success(request, "Disconnected from MQTT broker successfully.")
    else:
        messages.error(request, "Failed to disconnect from MQTT broker.")
    
    return redirect('mqtt_app:dashboard')

def get_recent_messages(request):
    """
    API view to get recent MQTT messages for AJAX updates
    """
    # Get last message ID from the request (if any)
    last_id = request.GET.get('last_id', 0)
    try:
        last_id = int(last_id)
    except ValueError:
        last_id = 0
    
    # Get newer messages
    new_messages = MQTTMessage.objects.filter(id__gt=last_id).order_by('-received_at')[:10]
    
    # Prepare data for response
    messages_data = []
    for msg in new_messages:
        messages_data.append({
            'id': msg.id,
            'topic': msg.topic,
            'payload': msg.payload,
            'qos': msg.qos,
            'received_at': msg.received_at.strftime('%Y-%m-%d %H:%M:%S'),
        })
    
    return JsonResponse({'messages': messages_data})
