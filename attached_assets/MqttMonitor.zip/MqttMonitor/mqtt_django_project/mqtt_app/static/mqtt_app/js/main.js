// Main JavaScript for MQTT Django App

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips if Bootstrap is available
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

    // Auto-close alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-persistent)');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            if (alert && alert.parentNode) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        }, 5000);
    });
    
    // TLS/SSL Configuration section toggle
    const tlsCheckbox = document.getElementById('id_use_tls');
    const tlsConfigSection = document.getElementById('tlsConfigSection');
    
    if (tlsCheckbox && tlsConfigSection) {
        // Initial state
        toggleTlsSection(tlsCheckbox.checked);
        
        // Listen for changes
        tlsCheckbox.addEventListener('change', function() {
            toggleTlsSection(this.checked);
        });
    }
    
    // Function to toggle TLS section visibility
    function toggleTlsSection(isVisible) {
        if (isVisible) {
            tlsConfigSection.style.display = 'block';
        } else {
            tlsConfigSection.style.display = 'none';
        }
    }

    // Function to format JSON in textareas with the 'json-format' class
    const jsonFormatButtons = document.querySelectorAll('.json-format');
    jsonFormatButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const textarea = document.getElementById(targetId);
            
            if (textarea) {
                try {
                    const json = JSON.parse(textarea.value);
                    textarea.value = JSON.stringify(json, null, 2);
                } catch (e) {
                    alert('Invalid JSON: ' + e.message);
                }
            }
        });
    });
});

// MQTT Dashboard specific functions
function refreshMQTTStatus() {
    // This function would be used to refresh MQTT connection status via AJAX
    // For now it's a placeholder - actual implementation would depend on server endpoints
}

// Función para intentar formatear JSON
function tryFormatJson(str) {
    try {
        const obj = JSON.parse(str);
        return JSON.stringify(obj, null, 2); // Formateo con sangría de 2 espacios
    } catch (e) {
        return str; // Devolver el string original si no es JSON válido
    }
}

// Función para determinar si un string es JSON válido
function isJsonString(str) {
    try {
        JSON.parse(str);
        return true;
    } catch (e) {
        return false;
    }
}

// Attach event listeners for message payload expansion toggle
document.addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('show-full-payload')) {
        e.preventDefault();
        const payloadDiv = e.target.previousElementSibling;
        const fullPayloadDiv = e.target.nextElementSibling;
        const payload = fullPayloadDiv.textContent;
        
        if (e.target.textContent === 'Show more') {
            // Si es JSON, formatearlo con sangría
            if (isJsonString(payload)) {
                const formattedJson = tryFormatJson(payload);
                // Usar <pre> para conservar el formato
                payloadDiv.innerHTML = '<pre class="json-content">' + formattedJson + '</pre>';
            } else {
                payloadDiv.textContent = payload;
            }
            e.target.textContent = 'Show less';
        } else {
            const truncatedText = payload.substring(0, 50) + '...';
            payloadDiv.textContent = truncatedText;
            e.target.textContent = 'Show more';
        }
    }
});
