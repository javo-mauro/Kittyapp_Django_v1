/**
 * JSON Formatter utility functions
 */

// Check if a string is valid JSON
function isJsonString(str) {
    if (typeof str !== 'string') return false;
    
    try {
        JSON.parse(str);
        return true;
    } catch (e) {
        return false;
    }
}

// Format JSON with proper indentation
function tryFormatJson(str) {
    if (typeof str !== 'string') return str;
    
    try {
        const obj = JSON.parse(str);
        return JSON.stringify(obj, null, 2); // Format with indent of 2 spaces
    } catch (e) {
        return str; // Return original string if not valid JSON
    }
}

// Format and display JSON in a pre tag
function formatJsonForDisplay(jsonStr) {
    if (!isJsonString(jsonStr)) return jsonStr;
    
    const formattedJson = tryFormatJson(jsonStr);
    return '<pre class="json-content">' + 
           formattedJson
               .replace(/&/g, '&amp;')
               .replace(/</g, '&lt;')
               .replace(/>/g, '&gt;')
               .replace(/"/g, '&quot;')
               .replace(/'/g, '&#039;') + 
           '</pre>';
}

// Setup click handlers for JSON payload expansion
document.addEventListener('DOMContentLoaded', function() {
    // Handle clicks on "Show more" for messages with full payloads
    document.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('show-full-payload')) {
            e.preventDefault();
            
            const payloadDiv = e.target.previousElementSibling;
            const fullPayloadDiv = e.target.nextElementSibling;
            const payload = fullPayloadDiv.textContent || fullPayloadDiv.innerText;
            
            if (e.target.textContent === 'Show more') {
                // If it's JSON, format it nicely
                if (isJsonString(payload)) {
                    payloadDiv.innerHTML = formatJsonForDisplay(payload);
                } else {
                    payloadDiv.textContent = payload;
                }
                e.target.textContent = 'Show less';
            } else {
                // Show the truncated version
                let truncated = payload;
                if (payload.length > 50) {
                    truncated = payload.substring(0, 50) + '...';
                }
                payloadDiv.textContent = truncated;
                e.target.textContent = 'Show more';
            }
        }
    });
});
