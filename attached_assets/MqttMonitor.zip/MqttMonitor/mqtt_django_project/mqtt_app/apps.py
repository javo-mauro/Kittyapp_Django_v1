"""
App configuration for the MQTT app
"""
from django.apps import AppConfig


class MqttAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mqtt_app'

    def ready(self):
        """
        Initialize the MQTT client when the app is ready.
        Note: This will run in development server but not in management commands.
        For background MQTT client, use the custom management command.
        """
        # Avoid import error when executing management commands
        try:
            from django.conf import settings
            # Don't start MQTT client in testing or when the app is not configured
            if not settings.configured or 'test' in settings.DATABASES:
                return
        except ImportError:
            return
