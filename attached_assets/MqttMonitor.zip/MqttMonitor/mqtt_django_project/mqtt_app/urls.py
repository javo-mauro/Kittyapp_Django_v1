"""
URL patterns for the MQTT app
"""
from django.urls import path
from . import views

app_name = 'mqtt_app'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('messages/', views.message_list, name='messages'),
    path('publish/', views.publish_view, name='publish'),
    path('settings/', views.settings_view, name='settings'),
    path('connect/', views.connect_mqtt, name='connect'),
    path('disconnect/', views.disconnect_mqtt, name='disconnect'),
    path('toggle-topic/<int:topic_id>/', views.toggle_topic_subscription, name='toggle_topic'),
    path('delete-topic/<int:topic_id>/', views.delete_topic, name='delete_topic'),
    path('api/recent-messages/', views.get_recent_messages, name='recent_messages'),
]
