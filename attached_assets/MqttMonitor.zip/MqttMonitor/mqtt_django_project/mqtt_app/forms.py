"""
Forms for the MQTT application
"""
from django import forms
from .models import MQTTConfiguration, MQTTTopic, MQTTMessage

class MQTTPublishForm(forms.Form):
    """
    Form for publishing MQTT messages
    """
    topic = forms.CharField(
        max_length=255,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        help_text="The MQTT topic to publish to"
    )
    payload = forms.CharField(
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 5}),
        help_text="The message payload"
    )
    qos = forms.ChoiceField(
        choices=[(0, '0 - At most once'), (1, '1 - At least once'), (2, '2 - Exactly once')],
        initial=0,
        widget=forms.Select(attrs={'class': 'form-control'}),
        help_text="Quality of Service level"
    )
    retain = forms.BooleanField(
        required=False,
        initial=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        help_text="Whether the message should be retained by the broker"
    )


class MQTTConfigurationForm(forms.ModelForm):
    """
    Form for configuring MQTT broker settings
    """
    class Meta:
        model = MQTTConfiguration
        fields = [
            'name', 'broker_host', 'broker_port', 
            'username', 'password', 'client_id', 'keepalive', 'is_active',
            'use_tls', 'ca_cert', 'client_cert', 'client_key', 'tls_version', 'cert_reqs'
        ]
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'broker_host': forms.TextInput(attrs={'class': 'form-control'}),
            'broker_port': forms.NumberInput(attrs={'class': 'form-control'}),
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'password': forms.PasswordInput(attrs={'class': 'form-control'}),
            'client_id': forms.TextInput(attrs={'class': 'form-control'}),
            'keepalive': forms.NumberInput(attrs={'class': 'form-control'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'use_tls': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'ca_cert': forms.Textarea(attrs={'class': 'form-control', 'rows': 5, 'placeholder': 'Pegue el contenido del certificado CA aquí'}),
            'client_cert': forms.Textarea(attrs={'class': 'form-control', 'rows': 5, 'placeholder': 'Pegue el contenido del certificado del cliente aquí'}),
            'client_key': forms.Textarea(attrs={'class': 'form-control', 'rows': 5, 'placeholder': 'Pegue el contenido de la clave privada aquí'}),
            'tls_version': forms.Select(attrs={'class': 'form-control'}),
            'cert_reqs': forms.Select(attrs={'class': 'form-control'}),
        }
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['ca_cert'].required = False
        self.fields['client_cert'].required = False
        self.fields['client_key'].required = False
        self.fields['tls_version'].required = False
        self.fields['cert_reqs'].required = False


class MQTTTopicForm(forms.ModelForm):
    """
    Form for managing MQTT topic subscriptions
    """
    class Meta:
        model = MQTTTopic
        fields = ['topic', 'qos', 'is_subscribed', 'is_json_payload', 'json_path_selector']
        widgets = {
            'topic': forms.TextInput(attrs={'class': 'form-control'}),
            'qos': forms.Select(attrs={'class': 'form-control'}),
            'is_subscribed': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'is_json_payload': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'json_path_selector': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '$.temperatura'}),
        }
