"""
Management command to start the MQTT client as a standalone process
"""
from django.core.management.base import BaseCommand
from django.conf import settings
import time
import logging
import sys
import signal
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Start the MQTT client as a standalone process'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.running = True
        signal.signal(signal.SIGINT, self.handle_signal)
        signal.signal(signal.SIGTERM, self.handle_signal)

    def handle_signal(self, sig, frame):
        self.stdout.write(self.style.WARNING('Received signal to terminate. Shutting down MQTT client...'))
        self.running = False

    def handle(self, *args, **options):
        # Import here to avoid circular imports
        from mqtt_app.mqtt_client import initialize_mqtt_client, disconnect_mqtt_client

        self.stdout.write(self.style.SUCCESS('Starting MQTT client...'))
        
        # Initialize the MQTT client
        client = initialize_mqtt_client()
        
        if client is None:
            self.stdout.write(self.style.ERROR('Failed to initialize MQTT client'))
            return
        
        self.stdout.write(self.style.SUCCESS('MQTT client initialized'))
        
        # Keep the command running until interrupted
        try:
            while self.running:
                if not client.is_connected():
                    self.stdout.write(self.style.WARNING('MQTT client disconnected. Attempting to reconnect...'))
                    # The client should reconnect automatically because of the loop_start() in initialize_mqtt_client
                
                time.sleep(5)  # Check status every 5 seconds
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error in MQTT client: {e}'))
        finally:
            # Clean shutdown
            self.stdout.write(self.style.WARNING('Shutting down MQTT client...'))
            disconnect_mqtt_client()
            self.stdout.write(self.style.SUCCESS('MQTT client shut down'))
