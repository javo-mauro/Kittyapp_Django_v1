"""
URL configuration for mqtt_django_project project.
"""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('mqtt_app.urls')),
]
