from django.apps import AppConfig


class KittyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kitty'
    verbose_name = 'Registro de mascotas'
